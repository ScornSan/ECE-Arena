#include "../prototypes.h"
#include "../structures.h"

void compteur_effet()
{

}
